/**
 * Created by rajab on 9/19/16.
 */
'use strict';

var previewsController = angular.module('previewsController', []);

previewsController.controller('previewController', ['$scope', function($scope) {

}]);