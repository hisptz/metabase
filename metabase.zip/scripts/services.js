/* global angular */

'use strict';

/* Services */

var metabaseServices = angular.module('metabaseServices', ['mainServices']);

