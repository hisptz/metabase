/* global angular */

'use strict';

/* Controllers */
var metabaseControllers = angular.module('metabaseControllers', ['mainController', 'packagesController', 'previewsController'])
