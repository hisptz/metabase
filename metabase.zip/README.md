Metadata Repository Manager
===============================

DHIS 2 Platform based HTML App for management of Metadata Repository
hosting metadata from mulitple dhis2 implementations for reuse within few clicks.

The Application is powered by AngularJS, HTML5 and CSS3

Authors
1. John Francis Mukulu <john.f.mukulu@gmail.com>
2. Rajab Mkomwa <rajeyw@gmail.com>
